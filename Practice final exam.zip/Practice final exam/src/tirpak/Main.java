package tirpak;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    static Scanner scanIn = new Scanner(System.in);

    public static void main(String[] args) {
        ArrayList<Integer> data = new ArrayList<>();
        System.out.println("1. Enter new room data ");
        System.out.println("2. View entered room data ");
        System.out.println("3. exit ");
        System.out.print("> ");
        int selection = scanIn.nextInt();
        while (selection != 3) {
            if (selection == 1) {
                getRoomId(data);
                int area = calcArea(getRoomShape());
                data.add(area);
                getIntro();
                selection = scanIn.nextInt();
                //          main(null);
            } else if (selection == 2) {
                displayStats(data);
                getIntro();
                selection = scanIn.nextInt();
                //          main(null);
            } else {
                System.out.println("Good bye. ");
                System.exit(0);
            }
        }
    }

    public static void getIntro() {
        System.out.println("1. Enter new room data ");
        System.out.println("2. View entered room data ");
        System.out.println("3. exit ");
        System.out.print("> ");
        System.out.println(" ");
    }

    public static void getRoomId(ArrayList<Integer> data) {
        System.out.println("Please enter room ID: ");
        int roomId = scanIn.nextInt();
        while (data.contains(roomId)) {
            System.out.println("Please enter a new room ID: ");
            roomId = scanIn.nextInt();
        }
        data.add(roomId);
    }

    public static int getRoomShape() {
        System.out.println("What shape is the room? ");
        System.out.println("1 - Circle ");
        System.out.println("2 - Square ");
        System.out.println("3 - Rectangle ");
        System.out.print("> ");
        int roomShape = scanIn.nextInt();
        boolean validInput = false;
        while (validInput) {
            try {
                validInput = true;
            } catch (InputMismatchException ime) {
                scanIn.nextInt();
                validInput = false;
            }

        }
        return roomShape;
    }

    public static int calcArea(int roomShape) {
        if (roomShape == 1) {
            System.out.println("Enter the diameter of the room: ");
            double diameter = scanIn.nextDouble();
            double circleArea1 = 0.25 * Math.PI * (diameter * diameter);
            int circleArea = (int) Math.round(circleArea1);
            return circleArea;
        } else if (roomShape == 2) {
            System.out.println("Enter the width of the room: ");
            double width = scanIn.nextDouble();
            double squareArea1 = width * width;
            int squareArea = (int) Math.round(squareArea1);
            return squareArea;
        } else {
            System.out.println("Enter the width of the room: ");
            double width = scanIn.nextDouble();
            double rectangleArea1 = width * width;
            int rectangleArea = (int) Math.round(rectangleArea1);
            return rectangleArea;
        }
    }

    public static void displayStats(ArrayList<Integer> data) {
        for (int i = 0; i < data.size(); i += 2) {
            System.out.println("This is your Room ID: " + data.get(i) + " Your total area for the whole room is: "
                    + data.get(i + 1));
//                if ((i += 2) == data.size()) {
//                    return;
//
//            System.out.println(data);
        }
    }
}
