package tirpak;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * This program is to determine the coefficient of linear
 * expansion of nickel experimentally
 *
 * @author Steven Tirpak
 * @version 1.0 5/7/2022
 */
public class Main {

    static Scanner scanIn = new Scanner(System.in);

    public static void main(String[] args) {
        ArrayList<Double> data = new ArrayList<>();
        System.out.println("1. Enter a new experiment? ");
        System.out.println("2. View experiment statistics? ");
        System.out.println("3. Exit ");
        System.out.print("> ");
        int selection = scanIn.nextInt();
        int totalExperiments = 0;
        double calculatedCoe = 0;
        while (selection != 3) {
            if (selection == 1) {
                data.add(getExperimentId(data));
                totalExperiments++;
                calculatedCoe += calcCoefficient();
                data.add(calculatedCoe);
                getIntro();
                selection = scanIn.nextInt();
            } else if (selection == 2) {
                displayStats(data);
                System.out.println("The average Coefficient is: " +
                        averageCoefficient(totalExperiments, calculatedCoe) + " oc.");
                getIntro();
                selection = scanIn.nextInt();
            } else {
                System.out.println("Good bye. ");
                System.exit(0);
            }
        }
    }

    public static double averageCoefficient(int totalExperiments, double calculatedCoe) {
        return calculatedCoe / totalExperiments;
    }

    public static void getIntro() {
        System.out.println();
        System.out.println("1. Enter a new experiment? ");
        System.out.println("2. View experiment statistics? ");
        System.out.println("3. Exit ");
        System.out.print("> ");
    }

    public static double getExperimentId(ArrayList<Double> data) {
        System.out.println("Enter experiment ID: ");
        System.out.print("> ");
        double expermentId = scanIn.nextInt();
        if (!data.contains(expermentId)) {
            data.add(expermentId);
        } else {
            System.out.println("Enter the new experiment ID: ");
            expermentId = scanIn.nextInt();
            data.add(expermentId);
            System.out.println("experiment ID is: " + (int) expermentId);

            System.out.println("please enter numeric values");
        }
        return expermentId;
    }

    public static double calcCoefficient() {
        final double finalLength;
        final double initialLength;
        double changeInTemp;
        double coefficientNi;
        System.out.println("What is the Length of nickel?");
        initialLength = scanIn.nextDouble();
        System.out.println("what is the final length expansion of the nickel once it is fully heated? ");
        finalLength = scanIn.nextDouble();
        System.out.println("What is the temperature of the metal celsius? ");
        changeInTemp = scanIn.nextDouble();
        System.out.println("Your length of the nickel at room temp is: " + initialLength + " mm");
        System.out.println("Your final length of nickel after fully heated is: " + finalLength + " mm");
        coefficientNi = (finalLength / initialLength - 1) / changeInTemp;
        //value of 13 x 10 - 6 / oC(0.000013)
        System.out.println("your coefficientNi is " + coefficientNi + " oC");
        return coefficientNi;
    }

    public static void displayStats(ArrayList<Double> data) {
        System.out.println("Experiment ID is: " + data);
        System.out.println("The final Length is: " + data);
    }
}