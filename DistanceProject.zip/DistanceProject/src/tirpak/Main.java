package tirpak;

/**
 * <p>
 * Author: Steven Tirpak
 * date: 4/18/2022
 */

import java.util.Scanner;

/**
 * This method uses a formula to determine cylinder circumferences and radius and area.
 * Also prints and displays as well as asking for inputs.
 *
 * //@param args Command-line arguments
 */

public class Main {

    public static void main(String[] args) {
        // Write your code here and do math.
        // I/O comments and displays.
        final double KM_IN_MI = 1.69034;
        Scanner scanIn = new Scanner(System.in);
        System.out.print("Enter a distance with km or mi at the end: ");
        double distance = scanIn.nextDouble();
        String units = scanIn.next();
        if (units.equals("km")) {
            distance /= KM_IN_MI;
            System.out.println(distance + " mi");
        } else {
            distance *= KM_IN_MI;
            System.out.println(distance + " km");
        }
        //Exit the project.
        System.exit(0);
    }
}
